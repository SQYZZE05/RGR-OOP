﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace РГР
{
    public partial class Form1 : Form
    {
        private List<Flight> flights;

        public Form1()
        {
            InitializeComponent();
            flights = new List<Flight>();
        }

        private void btnAddFlight_Click(object sender, EventArgs e)
        {
            string flightNumber = txtFlightNumber.Text;
            string planeName = txtPlaneName.Text;
            string departure = txtDeparture.Text;
            string destination = txtDestination.Text;
            DateTime departureTime = dtpDepartureTime.Value;
            DateTime arrivalTime = dtpArrivalTime.Value;
            decimal ticketPrice = nudTicketPrice.Value;

            Flight flight = new Flight(flightNumber, planeName, departure, destination, departureTime, arrivalTime, ticketPrice);
            flights.Add(flight);
            UpdateFlightList();
        }

        private void btnDeleteFlight_Click(object sender, EventArgs e)
        {
            if (lstFlights.SelectedItem is Flight selectedFlight)
            {
                flights.Remove(selectedFlight);
                UpdateFlightList();
            }
        }

        private void UpdateFlightList()
        {
            lstFlights.Items.Clear();
            foreach (var flight in flights)
            {
                lstFlights.Items.Add(flight);
            }
        }
    }
}
