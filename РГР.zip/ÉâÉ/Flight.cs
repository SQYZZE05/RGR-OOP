﻿using System;

namespace РГР
{
    public class Flight
    {
        public string FlightNumber { get; set; }
        public string PlaneName { get; set; }
        public string Departure { get; set; }
        public string Destination { get; set; }
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public decimal TicketPrice { get; set; }

        public Flight(string flightNumber, string planeName, string departure, string destination, DateTime departureTime, DateTime arrivalTime, decimal ticketPrice)
        {
            FlightNumber = flightNumber;
            PlaneName = planeName;
            Departure = departure;
            Destination = destination;
            DepartureTime = departureTime;
            ArrivalTime = arrivalTime;
            TicketPrice = ticketPrice;
        }

        public override string ToString()
        {
            return $"Flight {FlightNumber}: {PlaneName} from {Departure} to {Destination}, departs at {DepartureTime}, arrives at {ArrivalTime}, costs {TicketPrice:C}";
        }
    }
}
