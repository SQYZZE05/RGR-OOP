﻿namespace РГР
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtFlightNumber = new System.Windows.Forms.TextBox();
            this.txtPlaneName = new System.Windows.Forms.TextBox();
            this.txtDeparture = new System.Windows.Forms.TextBox();
            this.txtDestination = new System.Windows.Forms.TextBox();
            this.dtpArrivalTime = new System.Windows.Forms.DateTimePicker();
            this.dtpDepartureTime = new System.Windows.Forms.DateTimePicker();
            this.nudTicketPrice = new System.Windows.Forms.NumericUpDown();
            this.btnAddFlight = new System.Windows.Forms.Button();
            this.btnDeleteFlight = new System.Windows.Forms.Button();
            this.lstFlights = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudTicketPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // txtFlightNumber
            // 
            this.txtFlightNumber.Location = new System.Drawing.Point(30, 30);
            this.txtFlightNumber.Name = "txtFlightNumber";
            this.txtFlightNumber.Size = new System.Drawing.Size(100, 22);
            this.txtFlightNumber.TabIndex = 0;
            this.txtFlightNumber.Text = "Flight Number";
            // 
            // txtPlaneName
            // 
            this.txtPlaneName.Location = new System.Drawing.Point(150, 30);
            this.txtPlaneName.Name = "txtPlaneName";
            this.txtPlaneName.Size = new System.Drawing.Size(100, 22);
            this.txtPlaneName.TabIndex = 1;
            this.txtPlaneName.Text = "Plane Name";
            // 
            // txtDeparture
            // 
            this.txtDeparture.Location = new System.Drawing.Point(270, 30);
            this.txtDeparture.Name = "txtDeparture";
            this.txtDeparture.Size = new System.Drawing.Size(100, 22);
            this.txtDeparture.TabIndex = 2;
            this.txtDeparture.Text = "Departure";
            // 
            // txtDestination
            // 
            this.txtDestination.Location = new System.Drawing.Point(390, 30);
            this.txtDestination.Name = "txtDestination";
            this.txtDestination.Size = new System.Drawing.Size(100, 22);
            this.txtDestination.TabIndex = 3;
            this.txtDestination.Text = "Destination";
            // 
            // dtpArrivalTime
            // 
            this.dtpArrivalTime.Location = new System.Drawing.Point(270, 70);
            this.dtpArrivalTime.Name = "dtpArrivalTime";
            this.dtpArrivalTime.Size = new System.Drawing.Size(220, 22);
            this.dtpArrivalTime.TabIndex = 4;
            // 
            // dtpDepartureTime
            // 
            this.dtpDepartureTime.Location = new System.Drawing.Point(30, 70);
            this.dtpDepartureTime.Name = "dtpDepartureTime";
            this.dtpDepartureTime.Size = new System.Drawing.Size(220, 22);
            this.dtpDepartureTime.TabIndex = 5;
            // 
            // nudTicketPrice
            // 
            this.nudTicketPrice.Location = new System.Drawing.Point(510, 30);
            this.nudTicketPrice.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nudTicketPrice.Name = "nudTicketPrice";
            this.nudTicketPrice.Size = new System.Drawing.Size(100, 22);
            this.nudTicketPrice.TabIndex = 6;
            // 
            // btnAddFlight
            // 
            this.btnAddFlight.Location = new System.Drawing.Point(30, 110);
            this.btnAddFlight.Name = "btnAddFlight";
            this.btnAddFlight.Size = new System.Drawing.Size(100, 30);
            this.btnAddFlight.TabIndex = 7;
            this.btnAddFlight.Text = "Add Flight";
            this.btnAddFlight.UseVisualStyleBackColor = true;
            this.btnAddFlight.Click += new System.EventHandler(this.btnAddFlight_Click);
            // 
            // btnDeleteFlight
            // 
            this.btnDeleteFlight.Location = new System.Drawing.Point(150, 110);
            this.btnDeleteFlight.Name = "btnDeleteFlight";
            this.btnDeleteFlight.Size = new System.Drawing.Size(100, 30);
            this.btnDeleteFlight.TabIndex = 8;
            this.btnDeleteFlight.Text = "Delete Flight";
            this.btnDeleteFlight.UseVisualStyleBackColor = true;
            this.btnDeleteFlight.Click += new System.EventHandler(this.btnDeleteFlight_Click);
            // 
            // lstFlights
            // 
            this.lstFlights.FormattingEnabled = true;
            this.lstFlights.ItemHeight = 16;
            this.lstFlights.Location = new System.Drawing.Point(30, 160);
            this.lstFlights.Name = "lstFlights";
            this.lstFlights.Size = new System.Drawing.Size(580, 180);
            this.lstFlights.TabIndex = 9;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(640, 360);
            this.Controls.Add(this.lstFlights);
            this.Controls.Add(this.btnDeleteFlight);
            this.Controls.Add(this.btnAddFlight);
            this.Controls.Add(this.nudTicketPrice);
            this.Controls.Add(this.dtpDepartureTime);
            this.Controls.Add(this.dtpArrivalTime);
            this.Controls.Add(this.txtDestination);
            this.Controls.Add(this.txtDeparture);
            this.Controls.Add(this.txtPlaneName);
            this.Controls.Add(this.txtFlightNumber);
            this.Name = "Form1";
            this.Text = "Flight Manager";
            ((System.ComponentModel.ISupportInitialize)(this.nudTicketPrice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtFlightNumber;
        private System.Windows.Forms.TextBox txtPlaneName;
        private System.Windows.Forms.TextBox txtDeparture;
        private System.Windows.Forms.TextBox txtDestination;
        private System.Windows.Forms.DateTimePicker dtpArrivalTime;
        private System.Windows.Forms.DateTimePicker dtpDepartureTime;
        private System.Windows.Forms.NumericUpDown nudTicketPrice;
        private System.Windows.Forms.Button btnAddFlight;
        private System.Windows.Forms.Button btnDeleteFlight;
        private System.Windows.Forms.ListBox lstFlights;
    }
}
